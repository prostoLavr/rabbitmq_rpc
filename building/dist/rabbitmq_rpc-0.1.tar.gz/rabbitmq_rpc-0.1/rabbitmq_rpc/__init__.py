from rabbitmq_rpc.client import RpcClient, RpcClientWorker
from rabbitmq_rpc.server import declare_to_receive

